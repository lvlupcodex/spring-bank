package com.lvlup.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBankTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
